# -*- coding: utf-8 -*-
import glob
import os


def _limpiar_binarios_antiguos():
    """Elimina silenciosamente binarios .pyd de versiones anteriores que ya no están en uso."""
    carpeta = os.path.dirname(__file__)
    for ruta in glob.glob(os.path.join(carpeta, "*.pyd")):
        nombre = os.path.basename(ruta)
        if not nombre.startswith("motor_v1_5_6"):
            try:
                os.remove(ruta)
            except OSError:
                pass


def classFactory(iface):
    """Carga la clase principal del complemento compilado en QGIS."""
    _limpiar_binarios_antiguos()
    from .motor_v1_5_6 import AuditoriaICANHPlugin
    return AuditoriaICANHPlugin(iface)
