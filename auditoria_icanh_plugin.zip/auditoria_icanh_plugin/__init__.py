# -*- coding: utf-8 -*-
import importlib.util
import os
import shutil
import sys
import tempfile

_MOD_NAME = "motor_v2_0_0"


def _cargar_motor_desde_cache():
    """
    Copia el binario .pyd a una carpeta temporal del usuario y lo carga desde allí.
    Así Windows nunca bloquea los archivos dentro de plugins/auditoria_icanh_plugin,
    permitiendo que QGIS actualice el complemento en un clic sin errores de permisos.
    """
    carpeta_plugin = os.path.dirname(os.path.abspath(__file__))
    candidatos = [
        fn for fn in os.listdir(carpeta_plugin)
        if fn.startswith(_MOD_NAME) and fn.endswith(".pyd")
    ]
    if not candidatos:
        raise ImportError(f"No se encontró el binario compilado {_MOD_NAME}*.pyd en {carpeta_plugin}")

    nombre_pyd = candidatos[0]
    origen = os.path.join(carpeta_plugin, nombre_pyd)

    cache_dir = os.path.join(tempfile.gettempdir(), "auditoria_icanh_cache")
    os.makedirs(cache_dir, exist_ok=True)
    destino = os.path.join(cache_dir, nombre_pyd)

    if not os.path.exists(destino) or os.path.getsize(destino) != os.path.getsize(origen):
        try:
            shutil.copy2(origen, destino)
        except OSError:
            pass

    full_name = f"{__name__}.{_MOD_NAME}"
    if full_name in sys.modules:
        return sys.modules[full_name]

    spec = importlib.util.spec_from_file_location(full_name, destino)
    mod = importlib.util.module_from_spec(spec)
    sys.modules[full_name] = mod
    spec.loader.exec_module(mod)
    return mod


def classFactory(iface):
    """Carga la clase principal del complemento compilado en QGIS."""
    motor = _cargar_motor_desde_cache()
    return motor.AuditoriaICANHPlugin(iface)
