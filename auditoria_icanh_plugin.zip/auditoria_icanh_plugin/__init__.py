# -*- coding: utf-8 -*-

def classFactory(iface):
    """Carga la clase principal del complemento compilado en QGIS."""
    from .plugin_principal import AuditoriaICANHPlugin
    return AuditoriaICANHPlugin(iface)
